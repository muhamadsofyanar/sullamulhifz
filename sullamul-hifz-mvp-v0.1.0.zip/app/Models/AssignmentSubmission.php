<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AssignmentSubmission extends Model
{
    protected $fillable = ['assignment_recipient_id','submitted_by_user_id','attempt_number','guardian_notes','submitted_at','review_status','reviewed_by_teacher_id','teacher_feedback','reviewed_at','file_path','original_name','mime_type','file_size'];
    protected function casts(): array { return ['submitted_at'=>'datetime','reviewed_at'=>'datetime']; }
    public function recipient(): BelongsTo { return $this->belongsTo(AssignmentRecipient::class, 'assignment_recipient_id'); }
}
